var express = require('express')
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var users = require('./routes/users.js');
var cors = require('cors')
var app = express();

app.set('views',path.join(__dirname, 'views'));
app.set('port', process.env.PORT || '3000');
app.engine('html',require('ejs').renderFile);
app.set('view engine','ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser)
app.use(cors);

app.use(users);

module.exports = app;
